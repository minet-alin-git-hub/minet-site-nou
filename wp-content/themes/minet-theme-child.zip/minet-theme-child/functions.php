<?php
function child_enqueue_styles() {
    // Load parent theme styles
    wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
    
    // Load Google Font: Roboto Condensed
    wp_enqueue_style( 'child-google-fonts', 'https://fonts.googleapis.com/css2?family=Roboto+Condensed:wght@400;700&display=swap', false );
}
add_action( 'wp_enqueue_scripts', 'child_enqueue_styles' );
